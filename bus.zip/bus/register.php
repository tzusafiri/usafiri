<?php
include_once("includes/header.php");






?>




<section class="login py-5 border-top-1">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-8 align-item-center">
                    <div class="border border">
                        <h3 class="bg-gray p-4">Jisajili sasa</h3>
                        <form action="#">
                            <fieldset class="p-4">
                                <input type="email" placeholder="Barua pepe*" class="border p-3 w-100 my-2">
                                <input type="password" placeholder="Nenosiri*" class="border p-3 w-100 my-2">
                                <input type="password" placeholder="Thibitisha nenosiri*" class="border p-3 w-100 my-2">
                                <div class="loggedin-forgot d-inline-flex my-3">
                                        <input type="checkbox" id="registering" class="mt-1">
                                        <label for="registering" class="px-2">Kwa kujisajili, unakubaliana na <a class="text-primary font-weight-bold" href="terms-condition.php">Vigezo na Masharti</a></label>
                                </div>
                                <button type="submit" class="d-block py-3 px-4 bg-primary text-white border-0 rounded font-weight-bold">Jisajili</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <br><br>
    
    
    
    <?php


include_once("includes/footer.php");

?>