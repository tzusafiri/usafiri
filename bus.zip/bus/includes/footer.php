
<!--============================
=            Footer            =
=============================-->

<footer class="footer section section-sm">
  <!-- Container Start -->
  <div class="container">
    <div class="row p-0">
      <div class="col-lg-3 col-md-7 offset-md-1 offset-lg-0">
        <!-- About -->
        <div class="block about">
          <!-- footer logo -->
          <img src="images/logo1.png" alt="">
          <!-- description -->
          <h4 class="text-light">KUHUSU Usafiri.com</h4>
          <p class="alt-color">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
            laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>
      </div>
      <!-- Link list -->
      <div class="col-lg-3 col-md-3 offset-lg-0 pl-5">
        <div class="block">
          <h4>KURASA ZETU</h4>
          <ul>
          
							<li>
								<a class="" href="index.php">Mwanzo</a>
                            </li>
                            <li class="">
								<a class="" href="buses.php">Mabasi</a>
                            </li>
                            <li class="">
								<a class="" href="blog.php">Habari na matukio</a>
                            </li>
                            <li class="">
								<a class="" href="about-us.php">Kuhusu Usafiri.com</a>
                            </li>
                            <li class="">
								<a class="" href="contact-us.php">Wasiliana nasi</a>
                            </li>
                            <li class="">
								<a class="" href="terms-condition.php">Vigezo na masharti</a>
                            </li>



					
          </ul>
        </div>
      </div>
            <!-- social links -->
        <div class="col-lg-3 col-md-3">
        <div class="block">
          <h4>KURASA ZETU ZA MITANDAO YA KIJAMII</h4>
          <h3 class="pb-1 text-light">Tufuate</h3>
          <a class="fa fa-facebook border border-dark rounded p-3 text-light" href="" target="_blank"></a>
          <a class="fa fa-twitter border border-dark rounded p-3 text-light" href="" target="_blank"></a>
          <a class="fa fa-pinterest-p border border-dark rounded p-3 text-light" href="" target="_blank"></a>

        </div>


      </div>
      <!-- Link list -->
      <div class="col-lg-3 col-md-3 offset-md-1 offset-lg-0">
        <div class="block">
          <h4>ADIMINI</h4>
          <div>
          <a class="btn btn-outline-light btn-sm pl-3 pr-3 pt-2 pb-2" href="login.php"><strong>Ingia</strong></a>
          </div>

        </div>
      </div>


    </div>
  </div>
  <!-- Container End -->
</footer>
<!-- Footer Bottom -->
<footer class="footer-bottom">
  <!-- Container Start -->
  <div class="container">
    <div class="row">
      <div class="col-sm-6 col-12">
        <!-- Copyright -->
        <!-- <div class="copyright">
          <p>Copyright © <script>
              var CurrentYear = new Date().getFullYear()
              document.write(CurrentYear)
            </script>. All Rights Reserved, theme by <a class="text-primary" href="https://themefisher.com" target="_blank">themefisher.com</a></p>
        </div> -->
      </div>
      <div class="col-sm-6 col-12">
        <!-- Social Icons -->
        <ul class="social-media-icons text-right">
          <li><a class="fa fa-facebook" href="https://www.facebook.com/themefisher" target="_blank"></a></li>
          <li><a class="fa fa-twitter" href="https://www.twitter.com/themefisher" target="_blank"></a></li>
          <li><a class="fa fa-pinterest-p" href="https://www.pinterest.com/themefisher" target="_blank"></a></li>
          <li><a class="fa fa-vimeo" href=""></a></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- Container End -->
  <!-- To Top -->
  <div class="top-to">
  <h5 class="text-light mr-2">Rudi juu </h5> <a id="top" class="" href="#"><i class="fa fa-angle-up"></i></a>
    
  </div>
</footer>

<!-- JAVASCRIPTS -->
<script src="plugins/jQuery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/popper.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap-slider.js"></script>
  <!-- tether js -->
<script src="plugins/tether/js/tether.min.js"></script>
<script src="plugins/raty/jquery.raty-fa.js"></script>
<script src="plugins/slick-carousel/slick/slick.min.js"></script>
<script src="plugins/jquery-nice-select/js/jquery.nice-select.min.js"></script>
<script src="plugins/fancybox/jquery.fancybox.pack.js"></script>
<script src="plugins/smoothscroll/SmoothScroll.min.js"></script>
<!-- google map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
<script src="plugins/google-map/gmap.js"></script>
<script src="js/script.js"></script>

</body>

</html>