<!DOCTYPE html>
<html lang="en">
<head>

  <!-- SITE TITTLE -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mega Bus</title>
  
  <!-- FAVICON -->
  <link href="images/favicon.png" rel="shortcut icon">
  <!-- PLUGINS CSS STYLE -->
  <!-- <link href="plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet"> -->
  <!-- Bootstrap -->
  <link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="plugins/bootstrap/css/bootstrap-slider.css">
  <!-- Font Awesome -->
  <link href="plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Owl Carousel -->
  <link href="plugins/slick-carousel/slick/slick.css" rel="stylesheet">
  <link href="plugins/slick-carousel/slick/slick-theme.css" rel="stylesheet">
  <!-- Fancy Box -->
  <link href="plugins/fancybox/jquery.fancybox.pack.css" rel="stylesheet">
  <link href="plugins/jquery-nice-select/css/nice-select.css" rel="stylesheet">
  <!-- CUSTOM CSS -->
  <link href="css/style.css" rel="stylesheet">


  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>

<body class="body-wrapper">
<section>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<nav class="navbar navbar-expand-lg navbar-light navigation p-4">
					<a class="navbar-brand" href="index.php">
						<img src="images/logo1.png" alt="">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
					 aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav ml-auto main-nav ">
							<li class="nav-item active">
								<a class="nav-link" href="index.php">Mwanzo</a>
                            </li>
                            <li class="nav-item active">
								<a class="nav-link" href="buses.php">Mabasi</a>
                            </li>
                            <li class="nav-item active">
								<a class="nav-link" href="register.php">Jiunge na Usafiri.com</a>
                            </li>
                            <li class="nav-item active">
								<a class="nav-link" href="blog.php">Habari na matukio</a>
                            </li>
                            <li class="nav-item active">
								<a class="nav-link" href="about-us.php">Kuhusu Usafiri.com</a>
                            </li>
                            
                            <li class="nav-item active">
								<a class="nav-link" href="contact-us.php">Wasiliana nasi</a>
                            </li>
                            <li class="nav-item active">
								<a class="nav-link" href="terms-condition.php">Vigezo na masharti</a>
                            </li>



						</ul>
						<ul class="navbar-nav ml-auto mt-10">
							<li class="nav-item">
								<a class="btn btn-outline-dark btn-sm pl-3 pr-3 pt-2 pb-2" href="login.php"><strong>Ingia</strong></a>
                            </li>
						</ul>
					</div>
				</nav>
			</div>
		</div>
	</div>
</section>
<!--=================================
=            Single Blog            =
==================================-->
