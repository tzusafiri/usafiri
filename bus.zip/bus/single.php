<?php
include_once("includes/header.php");






?>


<section class="page-title-abc">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2 text-center">
				<!-- Title text -->
				<h3>ABC UPPER CLASS</h3>
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>
<section class="pt-5">
	<div class="container">
	<div class="row">
			<div class="col-md-12">
				<!-- Advance Search -->
				<div class="advance-search">
					<form>
						<div class="form-row">
							<div class="form-group col-md-4">
								<input type="text" class="form-control my-2 my-lg-0" id="inputtext4" placeholder="Kutoka">
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control my-2 my-lg-0" id="inputCategory4" placeholder="Kwenda">
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control my-2 my-lg-0" id="inputLocation4" placeholder="Muda">
							</div>
							<div class="form-group col-md-2">

								<button type="submit" class="btn btn-warning btn-sm">Tafuta</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
<section>
	<div class="container">
		<div class="row">
		<div class="col-md-4 bg-danger p-5">
				
                <!-- Safety tips widget -->
					<div class="text-light">
						<h5 class="widget-header text-light">KUHUSU ABC UPPER CLASS</h5>
						<ul>
							<li class="text-light">Meet seller at a public place</li>
							<li class="text-light">Check the item before you buy</li>
							<li class="text-light">Pay only after collecting the item</li>
							<li class="text-light">Pay only after collecting the item</li>
						</ul>
					</div>

				
	</div>
	<div class="col-md-4 bg-warning p-5">
				
                <!-- Safety tips widget -->
					<div class="text-light">
						<h5 class="widget-header text-light">KUHUSU ABC UPPER CLASS</h5>
						<ul>
							<li class="text-light">Meet seller at a public place</li>
							<li class="text-light">Check the item before you buy</li>
							<li class="text-light">Pay only after collecting the item</li>
							<li class="text-light">Pay only after collecting the item</li>
						</ul>
					</div>

				
	</div>
	<div class="col-md-4 bg-success p-5">
				
                <!-- Safety tips widget -->
					<div class="text-light">
						<h5 class="widget-header text-light">KUHUSU ABC UPPER CLASS</h5>
						<ul>
							<li class="text-light">Meet seller at a public place</li>
							<li class="text-light">Check the item before you buy</li>
							<li class="text-light">Pay only after collecting the item</li>
							<li class="text-light">Pay only after collecting the item</li>
						</ul>
					</div>

			
	</div>

		</div>


	</div>
</section>
<br><br>
<section class="section bg-gray">
<div class="container">
	<div class="container">
		<div class="row">
			<!-- Left sidebar -->
			<div class="col-md-12">
				<div class="product-details">
                	<!-- product slider -->
					<div class="product-slider pt-0">
						<div class="product-slider-item" data-image="images/products/abc.jpg">
							<img class="img-fluid w-100" src="images/products/abc.jpg" alt="product-img">
						</div>
						<div class="product-slider-item" data-image="images/products/abc.jpg">
							<img class="img-fluid w-100" src="images/products/abc.jpg" alt="product-img">
						</div>
						<div class="product-slider-item" data-image="images/products/abc.jpg">
							<img class="img-fluid w-100" src="images/products/abc.jpg" alt="product-img">
						</div>
						<div class="product-slider-item" data-image="images/products/abc.jpg">
							<img class="img-fluid w-100" src="images/products/abc.jpg" alt="product-img">
						</div>
					</div>
					<!-- product slider -->

					<div class="content mt-5 pt-5">
						<ul class="nav nav-pills  justify-content-center" id="pills-tab" role="tablist">
							<li class="nav-item">
								<a class="nav-link bg-success" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home"
								 aria-selected="true">Product Details</a>
							</li>
							<li class="nav-item">
								<a class="nav-link bg-warning" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile"
								 aria-selected="false">Specifications</a>
							</li>
							<li class="nav-item">
								<a class="nav-link bg-danger" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact"
								 aria-selected="false">MAONI</a>
							</li>
						</ul>
						<div class="tab-content" id="pills-tabContent">
							<div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
								<h3 class="tab-title">Product Description</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia laudantium beatae quod perspiciatis, neque
									dolores eos rerum, ipsa iste cum culpa numquam amet provident eveniet pariatur, sunt repellendus quas
									voluptate dolor cumque autem molestias. Ab quod quaerat molestias culpa eius, perferendis facere vitae commodi
									maxime qui numquam ex voluptatem voluptate, fuga sequi, quasi! Accusantium eligendi vitae unde iure officia
									amet molestiae velit assumenda, quidem beatae explicabo dolore laboriosam mollitia quod eos, eaque voluptas
									enim fuga laborum, error provident labore nesciunt ad. Libero reiciendis necessitatibus voluptates ab
									excepturi rem non, nostrum aut aperiam? Itaque, aut. Quas nulla perferendis neque eveniet ullam?</p>

							</div>
							<div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
								<h3 class="tab-title">Product Specifications</h3>
								<table class="table table-bordered product-table">
									<tbody>
										<tr>
											<td>Seller Price</td>
											<td>$450</td>
										</tr>
										<tr>
											<td>Added</td>
											<td>26th December</td>
										</tr>
										<tr>
											<td>State</td>
											<td>Dhaka</td>
										</tr>
										<tr>
											<td>Brand</td>
											<td>Apple</td>
										</tr>
										<tr>
											<td>Condition</td>
											<td>Used</td>
										</tr>
										<tr>
											<td>Model</td>
											<td>2017</td>
										</tr>
										<tr>
											<td>State</td>
											<td>Dhaka</td>
										</tr>
										<tr>
											<td>Battery Life</td>
											<td>23</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
								
								<div class="product-review">

									<div class="review-submission">
										<h3 class="tab-title">TUMA MAONI YAKO HAPA KUHUSU ABC UPPER CLASS</h3>
										<!-- Rate -->
										<div class="rate">
											<div class="starrr"></div>
										</div>
										<div class="review-submit">
											<form action="#" class="row">
												<div class="col-lg-6">
													<input type="text" name="name" id="name" class="form-control" placeholder="Name">
												</div>
												<div class="col-lg-6">
													<input type="email" name="email" id="email" class="form-control" placeholder="Email">
												</div>
												<div class="col-12">
													<textarea name="review" id="review" rows="10" class="form-control" placeholder="Message"></textarea>
												</div>
												<div class="col-12">
													<button type="submit" class="btn btn-main">Sumbit</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>


		</div>
	</div>
	<!-- Container End -->
</section>
<br><br>
	</div>
<?php


include_once("includes/footer.php");

?>