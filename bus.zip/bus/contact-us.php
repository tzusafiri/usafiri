<?php
include_once("includes/header.php");






?>


<!-- page title -->
<!--================================
=            Page Title            =
=================================-->
<section class="page-title">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2 text-center">
				<!-- Title text -->
				<h3>Mawasiliano</h3>
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>
<!-- page title -->
<br><br>
<div class="container">


<div class="row mt-5">
                       <!-- Category list -->
					<div class="col-lg-4 offset-lg-0 col-md-5 offset-md-1 col-sm-3 col-6">
						<a href="buses.php">
						<div class="category-block">
							<div class="header">
								<i class="fa fa-shopping-basket icon-bg-4"></i> 
								<h4>Simu</h4>
              </div>
              
              <h3 class="text-center"> 0693-307 286 </h3>
              <h3 class="text-center"> au </h3>
              <h3 class="text-center"> 0693-307 286 </h3>

						</div>
						</a>

					</div> <!-- /Category List -->
					<!-- Category list -->
					<div class="col-lg-4 offset-lg-0 col-md-5 offset-md-1 col-sm-3 col-6">
					<a href="buses.php">
						<div class="category-block">
							<div class="header">
								<i class="fa fa-briefcase icon-bg-5"></i> 
								<h4>Barua pepe</h4>
              </div>
              
              <h3 class="text-center"> usafiri@gmail.com </h3>
              <h3 class="text-center"> au </h3>
              <h3 class="text-center"> usafiri2@gmail.com </h3>

						</div>
					</a>
					</div> <!-- /Category List -->

					
					<!-- Category list -->
					<div class="col-lg-4 offset-lg-0 col-md-5 offset-md-2 col-sm-3 col-6">
					<a href="buses.php">
						<div class="category-block">
							
							<div class="header">
								<i class="fa fa-laptop icon-bg-8"></i> 
								<h4>Mitandao ya kijamii</h4>
              </div> 
                      <!-- Social Icons -->
        <div class="text-center pb-1">
          <h3 class="pb-1">Tufuate</h3>
          <a class="fa fa-facebook border border-dark rounded p-3" href="" target="_blank"></a>
          <a class="fa fa-twitter border border-dark rounded p-3" href="" target="_blank"></a>
          <a class="fa fa-pinterest-p border border-dark rounded p-3" href="" target="_blank"></a>
          <br>
          
</div>
						</div>
					</a>
					</div> <!-- /Category List -->
					
					
        </div>
</div>
			

<!-- contact us start-->
<section class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="contact-us-content p-2">
                    
                    <h1 class="pt-0">Unawaza nini kuhusu Usafiri.com?</h1>
                    <h2 class="pt-3 pb-5">Tungependa kusikia kutoka kwako. <br>Toa maoni yako.</h2>
                </div>
            </div>
            <div class="col-md-6">
                    <form action="#">
                        <fieldset class="p-4">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6 py-2">
                                        <input type="text" placeholder="Jina *" class="form-control" required>
                                    </div>
                                    <div class="col-lg-6 pt-2">
                                        <input type="email" placeholder="Barua pepe *" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <input type="tel" placeholder="Namba ya simu *" class="form-control" required>


                            <textarea name="message" id=""  placeholder="Ujumbe *" class="border w-100 p-3 mt-3 mt-lg-4"></textarea>
                            <div class="btn-grounp">
                                <button type="submit" class="btn btn-primary mt-2 float-right">Tuma</button>
                            </div>
                        </fieldset>
                    </form>
            </div>
        </div>
    </div>
</section>
<!-- contact us end -->

<?php


include_once("includes/footer.php");

?>