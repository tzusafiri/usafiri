<?php
include_once("includes/header.php");






?>




<!--===============================
=            Hero Area            =
================================-->

<section class="hero-area bg-1 text-center overly">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Header Contetnt -->
				<div class="content-block">
					<h1><strong>Usafiri.com</strong></h1><br>
					<p>Sasa unaweza kukata tiketi kutoka kampuni yoyote ya usafiri
					<br>wa mabasi unayoipenda kwenda popote nchini Tanzania.</p>
					
				</div>
				<!-- Advance Search -->
				<div class="advance-search">
						<div class="container">
							<div class="row justify-content-center">
								<div class="col-lg-12 col-md-12 align-content-center">
										<form>
											<div class="form-row">
												<div class="form-group col-md-4">
													<input type="text" class="form-control my-2 my-lg-1" id="inputtext4" placeholder="Kutoka">
												</div>
												<div class="form-group col-md-3">
													<input type="text" class="form-control my-2 my-lg-1" id="inputtext4" placeholder="Kwenda">

												</div>
												<div class="form-group col-md-3">
													<input type="text" class="form-control my-2 my-lg-1" id="inputtext4" placeholder="Muda">

												</div>
												<div class="form-group col-md-2 align-self-center">
													<button type="submit" class="d-block btn btn-primary">Tafuta</button>
												</div>
											</div>
										</form>
									</div>
								</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>

<!--===================================
=            Client Slider            =
====================================-->


<!--===========================================
=            Popular deals section            =
============================================-->

<section class="popular-deals section bg-gray">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
					<h2>Mabasi</h2>
					<p>Chagua basi ulitakalo sasa.</p>
				</div>
			</div>
		</div>
		<div class="row">
			<!-- offer 01 -->
			<div class="col-lg-12">
				<div class="trending-ads-slide">
					<div class="col-sm-12 col-lg-4">
						<!-- product card -->
<div class="product-item bg-light">
	<div class="card">
		<div class="thumb-content">
			<!-- <div class="price">$200</div> -->
			<a href="single.php">
				<img class="card-img-top img-fluid" src="images/products/shabiby.jpg" alt="Card image cap">
			</a>
		</div>
		<div class="card-body">
		    <h4 class="card-title"><a href="single.php">SHABIBY</a></h4>
		   
		    <p class="card-text"></p>

		</div>
	</div>
</div>



					</div>
					<div class="col-sm-12 col-lg-4">
						<!-- product card -->
<div class="product-item bg-light">
	<div class="card">
		<div class="thumb-content">
			<!-- <div class="price">$200</div> -->
			<a href="single.php">
				<img class="card-img-top img-fluid" src="images/products/abc.jpg" alt="Card image cap">
			</a>
		</div>
		<div class="card-body">
		    <h4 class="card-title"><a href="single.php">ABC UPPER CLASS</a></h4>
		   
		    <p class="card-text"></p>

		</div>
	</div>
</div>



					</div>
					<div class="col-sm-12 col-lg-4">
						<!-- product card -->
<div class="product-item bg-light">
	<div class="card">
		<div class="thumb-content">
			<!-- <div class="price">$200</div> -->
			<a href="single.php">
				<img class="card-img-top img-fluid" src="images/products/darlux.jpg" alt="Card image cap">
			</a>
		</div>
		<div class="card-body">
		    <h4 class="card-title"><a href="single.php">DAR LUX</a></h4>
		   
		    <p class="card-text"></p>

		</div>
	</div>
</div>



					</div>
					<div class="col-sm-12 col-lg-4">
						<!-- product card -->
<div class="product-item bg-light">
	<div class="card">
		<div class="thumb-content">
			<!-- <div class="price">$200</div> -->
			<a href="single.php">
				<img class="card-img-top img-fluid" src="images/products/tahmeed.png" alt="Card image cap">
			</a>
		</div>
		<div class="card-body">
		    <h4 class="card-title"><a href="single.php">TAHMEED</a></h4>
		   
		    <p class="card-text"></p>

		</div>
	</div>
</div>



					</div>



				</div>
			</div>
			
			
		</div>
	</div>
</section>



<!--==========================================
=            All Category Section            =
===========================================-->

<section class=" section">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<!-- Section title -->
				<div class="section-title">
					<h2>Aina za Mabasi</h2>
					<p>Chagua aina ya basi utakalo kwa huduma uipendayo.</p>
				</div>
				<div class="row">
                       <!-- Category list -->
					<div class="col-lg-4 offset-lg-0 col-md-5 offset-md-1 col-sm-3 col-6">
						<a href="buses.php">
						<div class="category-block">
							<div class="header">
								<i class="fa fa-shopping-basket icon-bg-4"></i> 
								<h4>Economy</h4>
							</div>

						</div>
						</a>

					</div> <!-- /Category List -->
					<!-- Category list -->
					<div class="col-lg-4 offset-lg-0 col-md-5 offset-md-1 col-sm-3 col-6">
					<a href="buses.php">
						<div class="category-block">
							<div class="header">
								<i class="fa fa-briefcase icon-bg-5"></i> 
								<h4>Semi-luxury</h4>
							</div>

						</div>
					</a>
					</div> <!-- /Category List -->

					
					<!-- Category list -->
					<div class="col-lg-4 offset-lg-0 col-md-5 offset-md-2 col-sm-3 col-6">
					<a href="buses.php">
						<div class="category-block">
							
							<div class="header">
								<i class="fa fa-laptop icon-bg-8"></i> 
								<h4>Luxury</h4>
							</div> 
						</div>
					</a>
					</div> <!-- /Category List -->
					
					
				</div>
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>


<!--====================================
=            Call to Action            =
=====================================-->

<section class="call-to-action overly bg-3 section-sm">
	<!-- Container Start -->
	<div class="container">
		<div class="row justify-content-md-center text-center">
			<div class="col-md-8">
				<div class="content-holder">
				    <h1 class="text-white">Unawaza nini kuhusu Usafiri.com?</h1>
					<h2>Kwa taarifa...shida....maoni au ushauri,wasiliana nasi sasa.</h2>
					<ul class="list-inline mt-30">
						<li class="list-inline-item"><a class="btn btn-main" href="contact-us.php">Bofya hapa</a></li>
						
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>
<?php


include_once("includes/footer.php");

?>



