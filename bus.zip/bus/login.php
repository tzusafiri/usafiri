<?php
include_once("includes/header.php");






?>




<section class="login py-5 border-top-1">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-8 align-item-center">
                <div class="border">
                    <h3 class="bg-gray p-4">Ingia kwenye akaunti</h3>
                    <form action="#">
                        <fieldset class="p-4">
                            <input type="text" placeholder="Jina*" class="border p-3 w-100 my-2">
                            <input type="password" placeholder="Neno la siri*" class="border p-3 w-100 my-2 mb-5">

                            <a href="user-profile.php" type="submit" class="py-3 px-5 bg-primary text-white border-0 rounded font-weight-bold mt-1 mb-3">Ingia</a>
                            
                            <a class="mt-3 d-block  text-primary" href="#">Umesahau neno la siri?</a>
                            <a class="mt-3 d-inline-block text-primary" href="register.php">Jisajili hapa</a>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<br><br>
<?php


include_once("includes/footer.php");

?>