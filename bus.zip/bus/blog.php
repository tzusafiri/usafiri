<?php
include_once("includes/header.php");






?>


<!--================================
=            Page Title            =
=================================-->
<section class="page-title">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2 text-center">
				<!-- Title text -->
				<h3>Habari na matukio</h3>
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>
<!--==================================
=            Blog Section            =
===================================-->

<section class="blog section">
	<div class="container">
		<div class="row">
		<div class="col-md-10 offset-md-1 col-lg-6 offset-lg-0">
							<!-- Article 01 -->
							<article>
	<!-- Post Image -->
	<div class="image">
		<img src="images/blog/post-1.jpg" alt="article-01">
	</div>
	<!-- Post Title -->
	<h3>Donec id dolor in erat imperdiet.</h3>
	<ul class="list-inline">
		<li class="list-inline-item">by <a href="">Admin</a></li>
		<li class="list-inline-item">Nov 22,2016</li>
	</ul>
	<!-- Post Description -->
	<p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores iusto tempore voluptatum blanditiis impedit alias magni ullam facilis perspiciatis magnam!</p>
	<!-- Read more button -->
	<a href="single-blog.php" class="btn btn-transparent">Read More</a>
</article>

		</div>
			<div class="col-md-10 offset-md-1 col-lg-6 offset-lg-0">

							<!-- Article 01 -->
							<article>
	<!-- Post Image -->
	<div class="image">
		<img src="images/blog/post-1.jpg" alt="article-01">
	</div>
	<!-- Post Title -->
	<h3>Donec id dolor in erat imperdiet.</h3>
	<ul class="list-inline">
		<li class="list-inline-item">by <a href="">Admin</a></li>
		<li class="list-inline-item">Nov 22,2016</li>
	</ul>
	<!-- Post Description -->
	<p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores iusto tempore voluptatum blanditiis impedit alias magni ullam facilis perspiciatis magnam!</p>
	<!-- Read more button -->
	<a href="single-blog.php" class="btn btn-transparent">Read More</a>
</article>


			</div>
							<!-- Pagination -->
							<nav aria-label="Page navigation example">
				  <ul class="pagination">
				    <li class="page-item active"><a class="page-link" href="#">1</a></li>
				    <li class="page-item"><a class="page-link" href="#">2</a></li>
				    <li class="page-item"><a class="page-link" href="#">3</a></li>
				    <li class="page-item">
				      <a class="page-link" href="#" aria-label="Next">
				        <span aria-hidden="true"><i class="fa fa-angle-right"></i></span>
				        <span class="sr-only">Next</span>
				      </a>
				    </li>
				  </ul>
				</nav>

</div>
	</div>
</section>

<?php


include_once("includes/footer.php");

?>